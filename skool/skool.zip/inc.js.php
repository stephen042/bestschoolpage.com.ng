<script>
var resizefunc = [];
</script>

<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/bootstrap.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/detect.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/fastclick.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.slimscroll.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.blockUI.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/waves.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/wow.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.nicescroll.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/peity/jquery.peity.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/waypoints/lib/jquery.waypoints.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/counterup/jquery.counterup.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/morris/morris.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/raphael/raphael-min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/jquery-knob/jquery.knob.js"></script>
<!--<script src="<?php echo SITE_URL; ?>skool/assets-new/pages/jquery.dashboard.js"></script>-->
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.core.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/js/jquery.app.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/multiselect/js/jquery.multi-select.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/select2/select2.min.js" type="text/javascript"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo SITE_URL; ?>skool/assets-new/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

 
 
 <!--
<script src="<?php echo SITE_URL; ?>skool/assets/js/final.js"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>skool/assets/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>skool/assets/css/bootstrap-datepicker3.css"/>-->
 
 
<script>
$(document).ready(function() {
   	
	$('#datatable').DataTable({});
	$('#datatable1').DataTable({});

	jQuery('.datepicker').datepicker({
		autoclose: true,
		format: "yyyy-mm-dd",
		todayHighlight: true
    });
});
</script>
