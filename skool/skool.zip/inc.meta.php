<title>Administrator</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no">
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<link href="<?php echo SITE_URL; ?>skool/assets/css/final.css" rel="stylesheet" type="text/css" />

<script type="text/javascript">
function del(url)
{  
	if(	confirm('Really want to delete this.') )
	{
		window.location=url;
	}
}
</script>
 <style>
.alert-error {
	color: #a94442;
	background-color: #f2dede;
	border-color: #ebccd1;
}
.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th {
    border-bottom: none!important;
	border-top: none!important;
}
..user-details { padding:0px; }
#sidebar-menu {
    padding-bottom: 0px;
    padding-top: 0px;
}
#sidebar-menu>ul>li>a {
    padding: 10px 20px;
}
#maknewside {
z-index: 9999999999999999999999999999999;
}

@media only screen and (max-width: 768px) {
	
	.shclnmdcls { font-size:18px!important; }
	.side-menu.left {
		top: 60px!important;
	}
	.topbar-left {
		display: none!important;
	}
	
	.content-page > .content {
    padding: 0px !important; 
	}
	.zasw {
     height: auto!important;
 	}
	.dashnewnn .count  {
    font-size: 22px!important;
	}
	#maknewside {
		z-index: 0;
	}
	
.sectionza {
   /*  background: white;*/
    height: auto!important; 
}


.dashnewnn .count  {
    font-size: 22px!important;
	}
	
}
.tablthisresponsive::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 1px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
	border-radius: 15px;
}
.tablthisresponsive::-webkit-scrollbar
{
	width: 1px;
	background-color: #F5F5F5;
	height: 10px;
}
.tablthisresponsive::-webkit-scrollbar-thumb
{
	background-color: #1b3058cc;
	border-radius: 15px;
	background-image: -webkit-linear-gradient(0deg,
	                                          rgba(255, 255, 255, 0.5) 25%,
											  transparent 25%,
											  transparent 50%,
											  rgba(255, 255, 255, 0.5) 50%,
											  rgba(255, 255, 255, 0.5) 75%,
											  transparent 75%,
											  transparent)
}
.paginate_button  a {font-size:0px; border:none!important; background: transparent!important; }
#example_wrapper .col-sm-6{ width:100%!important; }
#example_wrapper ul.pagination  { width:100%!important; }
#example_wrapper ul.pagination li:last-child {
  padding: 0px!important;
    float: right!important;
	    margin-right: 25px!important;
}
.pagination li{ cursor:pointer!important; }
.pagination .next a{ cursor:pointer!important; }
div.dataTables_filter label {
    width: 90%!important;
}
div.dataTables_filter input {
    width: 100%!important;
}
</style>
