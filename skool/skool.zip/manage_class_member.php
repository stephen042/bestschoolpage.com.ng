<?php
include('../config.php');
include('inc.session-create.php'); 
$validate = new validation();
$pageTitle = 'Manage Class Member';
$Filename = 'manage_class_member.php';


 $studetail=$db->getRow("select * from school_class where randomid='".$_GET['randomid']."' and create_by_userid='".$create_by_userid."'");

 $newStudetail=$db->getRow("select * from school_class where randomid='".$_GET['new_randomid']."' and create_by_userid='".$create_by_userid."'");

if(isset($_POST['update_class_id']))
{
	foreach($_POST['class_id'] as $key=>$val)
	{
	$aryData=array(	
	              'class'      =>     $studetail['id'],	
				    );  
	$flgIn1 = $db->updateAry("manage_student",$aryData,"where id='".$_POST['class_id'][$key]."'");

		
	}
}


?>
<!DOCTYPE html>
<html>
<head>
    <?php include('inc.meta.php'); ?>
	
	 <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Droid+Serif" />
<style>



body, label, span, a, .gwt-Button {
	
	 font-family: 'Droid Serif' !important; 
}
		
#datatable_filter input[type=search] {
 
    width: 60.6%;
}

div.dataTables_filter label {
    position: relative;
    width: 25% !important;
    text-align: left;
    float: right!important;
    border: 0!important;
}		
		
.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th {
    border-bottom: 1px solid #ddd!important;
}	
.zqw22 .with-nav-tabs input[type=text] {
    width: 79px !important;
}

.zqw22 input[type=checkbox] {
    width: auto !important;
}
        .page-title {
            font-size: 20px;
            margin-bottom: 0;
            margin-top: 7px;
            text-align: center;
            background: white;
            padding: 23px 0 30px 0px;
            border-bottom: 5px solid gainsboro;
        }

        .zasw {
            border: 1px solid gainsboro;
            height: 1000px;
            margin-top: 18px;
        }

        .zasw1 {
            height: 1000px;
            margin-top: 18px;
        }
		
	#datatable_wrapper div.dataTables_filter label {
    position: relative;
    width: 22% !important;
    text-align: left;
    float: right !important;
}

#datatable_wrapper #datatable_filter input[type=search] {
   width: 70% !important;
    margin: 0;
}

        .sectionza {
            background: white;
            height: 1000px;
        }

        .top-serche input {
            padding: 5px 49px 5px 14px;
            border: 2px solid gainsboro;
            border-radius: 4px;
            position: relative;
        }

        .top-serche {
            padding: 32px 0 9px 30px;
        }

        .content-page > .content {
            margin-bottom: 60px;
            margin-top: 60px;
            padding: 20px 30px 15px 78px;
            background: white;
        }

        .zswqas ul {
            list-style: none;
        }

        .zswqas li a span i {
            font-size: 29px;
            padding-top: 9px;
        }

        .zswqas li a span {
            padding-right: 16px;
        }

        .zswqas li a {
            width: 239px;
            display: block;
            padding: 16px 14px 14px 18px;
            border-bottom: 2px solid gainsboro;
        }

        .topside-section ul {
            display: inline-flex;
            list-style: none;
        }

        .topside-section li {
            padding: 0 11px 0 0;
        }

        .topside-section {
            padding-top: 8px;
            border: 1px solid gainsboro;
            box-shadow: 1px 6px 4px gainsboro;
            padding: 14px 8px 11px 1px;
        }

        .zqw22 .panel-success > .panel-heading {
            background: white;
        }

        .zqw22 .nav.nav-tabs > li > a:hover, .nav.tabs-vertical > li > a:hover {
            color: black !important;
            font-weight: 700;

        }
		
		div.dataTables_filter label {
    position: relative;
    width: 85% !important;
    text-align: left;
    font-weight: 400;
    white-space: nowrap;
    text-align: left;
    border: 1px solid gainsboro !important;
    padding: 4px 13px 4px 10px;
    border-radius: 5px;
    color: black;
    /* margin: 0 auto; */
    float: left !important;
    margin-left: 16px;
		}
		
		
		div.dataTables_filter label {
    position: relative;
    width: 85% !important;
    text-align: left;
    font-weight: 400;
    white-space: nowrap;
    text-align: left;
    border: 1px solid gainsboro !important;
    padding: 4px 13px 4px 10px;
    border-radius: 5px;
    color: black;
		}

        .zqw22 .nav.nav-tabs > li > a, .nav.tabs-vertical > li > a {

            border-top-right-radius: 10px;
            border-top-left-radius: 10px;
            font-size: 10px;
            height: 38px;
            margin-top: 0;
        }

        div.dataTables_filter label {
            font-weight: 400;
            white-space: nowrap;
            text-align: left;
            border: 1px solid gainsboro;
            padding: 4px 13px 4px 0px;
            border-radius: 5px;
            color: black;
        }

        #example .active {
            background: #1B3058;
            color: white;
        }

        .zqw22 .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover, .tabs-vertical > li.active > a, .tabs-vertical > li.active > a:focus, .tabs-vertical > li.active > a:hover {
            color: black !important;
            font-weight: 700;
            line-height: 38px;

            background: gainsboro;

        }

        .zqw22 .panel-success > .panel-heading {
            background: white;
            padding: 0;
        }

        .zqw22 .panel .panel-body {
            border-right: none !important;
            border: 1px solid gainsboro;
        }

        .gwt-Label {
            padding: 8px;
        }

        .zqw22 input {
            padding: 8px 3px 10px 0;
            border: 1px solid gainsboro;
            background: #dcdcdc45;
            border-radius: 5px;
            margin-right: 0px;
            width: 156px;
            margin: 8px 0 11px 0;
            margin-bottom: 5px;
        }

        .sectsab a ul {

            padding: 0px;
        }

        .sectsab.active li {

            color: white;
            font-weight: 600;

        }

        .zqw22 button {
            border: 1px solid #1B3058;
            padding: 4px 5px 4px 5px;
            margin-right: 7px;
            background: transparent;
            color: #1B3058;
        }

        .zqw22 select {
            padding: 5px 0 8px 0;
            background: #dcdcdc2e;
        }

        .zqw22 .nav-tabs > li {

            padding: 0 4px 0 0;
        }

        #tab3success, #tab4success .middleCenterInner {
            border: 1px solid gainsboro;
            padding: 17px 11px 51px 19px;
        }

        #tab3success .middleCenterInner {
            border: 1px solid gainsboro;
            padding: 17px 11px 51px 19px;
        }
		
		#example td {
    padding: 4px 11px 4px 13px;
    border-bottom: 3px solid;
    margin: 0 0 0;
}

        #tab3success, #tab4success .BFOGCKB-c-h {
            border-bottom: 3px solid;
            width: 300px;
        }

        #tab3success .BFOGCKB-c-h {
            border-bottom: 3px solid;
            width: 300px;
        }

        #tab3success, #tab4success {
            border: 1px solid gainsboro;
            padding: 14px 4px 42px 11px;
            width: 361px;
        }

        #tab3success, #tab4success .gwt-DecoratorPanel {

            padding: 21px 21px 43px 4px;
        }

        #tab3success .gwt-DecoratorPanel {

            padding: 21px 21px 43px 4px;
        }

        .zqw22 .panel .panel-body {
            overflow-x: auto;
            border-bottom: 3px solid gainsboro !important;
        }

        .zqw22 .nav.nav-tabs > li > a, .nav.tabs-vertical > li > a {

            background: #dcdcdc4f !important;
        }

        .table-bordered > tbody > tr > td, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > td, .table-bordered > tfoot > tr > th, .table-bordered > thead > tr > td, .table-bordered > thead > tr > th {
            border: 1px solid #ebeff200;
        }

        div.dataTables_info {

            margin-left: 7px;
        }

        table.dataTable {

            margin-top: 0px !important;
            margin-bottom: 0px !important;
        }

        .zqw22 .nav.nav-tabs > li > a, .nav.tabs-vertical > li > a {
            color: black !important;
            font-weight: 700;
            line-height: 38px;

            background: gainsboro;

        }

        .nav.nav-tabs > li > a, .nav.tabs-vertical > li > a {
            padding-left: 15px !important;
            padding-right: 15px !important;
        }

        .dataTables_paginate a {
            background-color: transparent;
            margin: 0 0px 0;
            padding: 8px 15px 9px;
            color: white;
            cursor: pointer;
            border: none;
        }

        .zqw22 .nav-tabs > li.active, .nav-tabs > li.active:focus, .nav-tabs > li.active:hover, .tabs-vertical > li.active, .tabs-vertical > li.active:focus, .tabs-vertical > li.active:hover {
            color: black !important;
            font-weight: 700;

        }

        .zswqas .activate a {
            width: 239px;
            display: block;
            padding: 16px 14px 14px 18px;
            border-bottom: 2px solid gainsboro;
            background: #1B3058;
            color: white;
        }

        .zqw22 .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover, .tabs-vertical > li.active > a, .tabs-vertical > li.active > a:focus, .tabs-vertical > li.active > a:hover {
            border-bottom: 3px solid #1B3058;
        }

        .topside-section li a {
            border: 1px solid #1B3058;
            padding: 5px 5px 4px 5px;
            display: block;
        }

        .zswqas li a:hover {
            width: 239px;
            display: block;
            padding: 16px 14px 14px 18px;
            border-bottom: 2px solid gainsboro;
            background: #1B3058;
            color: white;
        }

        .zswqas .active {
            width: 239px;
            display: block;
            padding: 16px 14px 14px 18px;
            border-bottom: 2px solid gainsboro;
            background: #1B3058;
            color: white;
        }

        .Wizard-a1 #example_length {

            display: none;
        }

        div.dataTables_filter label {
            font-weight: 400;
            white-space: nowrap;
            text-align: left;

        }

        div.dataTables_filter input {
            margin-left: .5em;
            display: inline-block;
            float: right;
            border: none;

        }

        div.dataTables_filter label {
            padding: 10px;
        }

        div.dataTables_filter input {
            margin-left: .5em;
            display: inline-block;
            float: right;
        }

        div.dataTables_filter {
            text-align: center;
        }

        .Wizard-a1 .zwq img {
            width: 50px;
        }

        .Wizard-a1 .zwq {
            padding-right: 8px;
			float:  left;
        }

        .Wizard-a1 .setting {
            display: none;
        }

        .Wizard-a1 .dataTables_info {
            margin: 0 auto !important;
            text-align: center;
            font-size: 12px;
            float: initial;
            position: absolute;
            bottom: 11px;
            left: 0;
            right: 0;
        }

        #example {
            width: 100% !important;
            margin: 0 auto;
        }

        div.dataTables_filter input {
            width: 67%;
        }

        div.dataTables_filter label {

            line-height: 23px;
        }

        .dataTables_paginate #example_previous:before {

            content: "";
            width: 0;
            height: 0;
            border-top: 6px solid transparent;
            border-right: 12px solid #555;
            border-bottom: 6px solid transparent;
            position: absolute;
            z-index: 999999;
            left: 15px;
            bottom: 3px;
        }

        .Wizard-a1 .dataTables_info {

            position: sticky !important;

        }

        div.dataTables_paginate {

            position: relative;
            top: -47px;
        }

        .dataTables_paginate a {
            background-color: transparent;
            margin: 0 0px 0;
            padding: 8px 15px 9px;
            color: white;
            cursor: pointer;
            border: none;
            position: static;
        }

        .dataTables_paginate .next {
            background: none;
            border: navajowhite;
            position: relative;
            color: white !important;
            position: relative;

        }

        div.dataTables_paginate {
            margin: 0;
            white-space: nowrap;
            text-align: center !important;
            padding-top: 27px;
        }

        .dataTables_paginate .disabled {
            background: none;
            color: white;
            border: none !important;
            padding: unset;
            display: block;

            color: transparent !important;

        }

        .tab-content .dataTables_paginate .disabled, .tab-content .paginate_button.previous.disabled {

            bottom: -105px;
        }

        #example2_paginate .paginate_button.previous:before, #example1_paginate .paginate_button.previous:before {

            bottom: -140px !Important;
        }

        .paginate_button.previous.disabled {
            width: 10%;
            float: left;
        }

        .paginate_button.previous.disabled {
            width: 10%;
            float: right;
        }

        div.dataTables_info {
            white-space: nowrap;
            padding-top: 0px;
        }

        .dataTables_paginate #example_next:before, .dataTables_paginate #example1_next:before, .dataTables_paginate #example2_next:before {
            content: "";
            width: 0;
            height: 0;
            border-top: 6px solid transparent;
            border-left: 12px solid #555;
            border-bottom: 6px solid transparent;
            position: absolute;
            z-index: 999999;
            right: 15px;
            bottom: 9px;
            top: 4px;
        }

        div.dataTables_paginate {
            margin: 0;
            white-space: nowrap;
            text-align: center !important;
        }

        .paging_simple_numbers span {
            /* display: none; */
            opacity: 0;
        }

        #example td {
            padding: 4px 11px 4px 13px;
            border-bottom: 3px solid;
            margin: 0 0 0;
        }

        #example .active:hover {
            background: #1B3058;
            color: white;
        }

        .Wizard-a1 .sorting_1 {
            display: none;
        }

        .dataTables_filter label:before {
            position: absolute;
            /* left: 0; */
            right: 46px;
            top: 62px !important;
            /* bottom: 0; */
            border: 1px solid #1B3058;
        }

        .dataTables_filter:before {
            content: '';
            position: absolute;
        }

        div.dataTables_filter label {
            position: relative;
            width: 85%;
            text-align: left;
        }

        div.dataTables_filter {
            margin-top: 20px;
        }

        .sectsab li {

            list-style: none;
        }

        div.dataTables_paginate {

            margin: 0 auto;
        }

        .gridTable {
            margin-bottom: 15px;

        }

        .gwt-Label {
            width: 90px;
            float: left;
            font-size: 13px;
        }

        #setB input {
            width: 15%;
        }

        .gwt-ListBox {
            width: 60%
        }

        .beddy img {
            width: 100%;
        }

        .beddy-b input {
            height: 50px;
            width: 100%;
        }

        .hhf button {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .desh {
            border-bottom: 2px solid;
            border-bottom-style: dashed;
            margin: 20px 0 20px 0px;
        }

        .ssd {
            text-align: center;
            margin: 10px 0 0 0;
            padding-bottom: 10px;
        }

        #example2_paginate .paginate_button.previous:before, #example1_paginate .paginate_button.previous:before {
            content: "";
            width: 0;
            height: 0;
            border-top: 6px solid transparent;
            border-right: 12px solid #555;
            border-bottom: 6px solid transparent;
            position: absolute;
            z-index: 999999;
            left: 15px;
            bottom: 3px;

        }

        #example2_length {

            display: none;
        }

        #example2_paginate .paginate_button.next:before, #example1_paginate .paginate_button.next:before {
            content: "";
            width: 0;
            height: 0;
            border-top: 6px solid transparent;
            border-left: 12px solid #555;
            border-bottom: 6px solid transparent;
            position: absolute;
            z-index: 999999;
            right: 0;
            bottom: 9px;
            top: 4px;
        }

        #example2_paginate, #example1_paginate {

            height: 10px !important;
        }

        #example2_filter.dataTables_filter input,
        #example1_filter.dataTables_filter input, example1_filter.dataTables_filter input {
            width: 95%;
            float: left;
        }

        #example2_filter.dataTables_filter label, #example1_filter.dataTables_filter label {
            position: relative;
            width: 50%;
            color: transparent;
            padding: 0;
            vertical-align: bottom;
        }

        #example2_filter.dataTables_filter label, #example1_filter.dataTables_filter label, #example_filter.dataTables_filter label {

            min-height: 39px;
            max-height: 22px;

        }

        #example2_filter.dataTables_filter input, #example1_filter.dataTables_filter input {

            position: relative;
            bottom: 27px;
            height: 29px;
            color: black;

        }

        #example1 div.dataTables_filter, #example2 div.dataTables_filter, #example div.dataTables_filter {
            text-align: left;
            margin-bottom: 10px;
            margin-left: 12px;
        }

        #example1 tbody input, #example2 tbody input, #example tbody input {

            width: 100% !important;
        }

        #example1_wrapper, #example2_wrapper {
            position: relative;
            padding-bottom: 15px;
        }

        #example1 thead, #example2 thead, #example thead {
            position: absolute;
            bottom: -61px;
            width: 100%;
            border: 1px solid #e4e1e175;
            left: 0;
        }

        #example1_filter, #example2_filter {
            Position: absolute;
            bottom: 0px;
            width: 100%;
            margin-left: -13px;
            text-align: right;
            /* margin: 0; */
            margin-top: 0;

        }

        .middleCenterInner .gwt-DecoratorPanel, .middleCenterInner table:first-child {

            width: 100% !important;
        }

        #example1_filter div.dataTables_filter {
            text-align: LEFT !IMPORTANT;
        }

        .zqw22 .panel .panel-body {

            padding-bottom: 82px;
        }
    </style>

</head>

<body class="fixed-left">
<div id="wrapper">
    <?php include('inc.header.php'); ?>
    <?php include('inc.sideleft.php'); ?>
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="page-title"><?php echo $PageTitle; ?></h4>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo $PageTitle; ?>">Home</a></li>
                            <li class="active"><?php echo $pageTitle; ?></li>
                        </ol>
                    </div>
                </div>

                <!-- Basic Form Wizard -->

                <div class="row">
                 
						 <?php  if($_GET['action']=="")  { ?>


                        <div class="card-box">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Serial no.</th>
									<th>SESSION</th>
                                    <th>CLASS</th>
                                    <th>Action</th>
                                   

                                </tr>
                                </thead>
                                <tbody> 
								<?php 
								
								$i=1;
								
								$classDetail=$db->getRows("select * from school_class where create_by_userid='".$create_by_userid."'");
								foreach($classDetail as $iList) { ?>
                               <tr>
							   <td><?php echo $i++; ?></td> 
							   	 <td><?php echo $db->getVal("select session from school_session where id='".$iList['session_id']."'"); ?></td> 
							   <td><?php echo $iList['name']; ?></td> 
							  
						
							  <td><a href="<?php echo $FileName; ?>?action=classes&randomid=<?php echo $iList['randomid']; ?>">Import Class Member</a></td>
							   
							   </tr>
								<?php }  ?>
                                </tbody>
                            </table>
                        </div>
						</div>
						
				 <?php } elseif($_GET['action']=='classes') { ?>
			<div class="row">
			<div class="sectionza">
			<div class="col-md-12">
				<div class="col-md-3">
						<div class="zasw ">
							<div class="zawq Wizard-a1">
								<table id="example" class="display">

						<tbody>
				<?php 
				$aryDetail = $db->getRows("select * from school_class where randomid!='".$_GET['randomid']."' and create_by_userid='".$create_by_userid."' ");
				foreach ($aryDetail as $iList) {
					?>
				<tr>
					<td style="padding:0px;"></td>
					<td class="sectsab <?php if ($_GET['new_randomid'] == $iList['randomid']) { echo "active";} ?>">
					<a href="<?php echo $FileName; ?>?action=classes&randomid=<?php echo $_GET['randomid'];?>&new_randomid=<?php echo $iList['randomid'];?>">
					<ul>
						<li>
							<span class="zwq"><i class="fa fa-book"
							style="font-size:48px"></i></span>
							<span class="subject">
						<?php echo $iList['name']; ?><br>
						<?php echo $db->getVal("select session from school_session where id = '" . $iList['session'] . "' "); ?>
							</span>

						</li>
					</ul>
					</a>
					</td>
				</tr>
	<?php } ?>
				</tbody>
					<tfoot>
					<thead>
					<tr class="setting">
						<th>Name</th>
						<th>Position</th>
					</tr>
					</thead>
					</tfoot>
			</table>
							</div>
									</div>
										</div>
			<div class="zasw1">
				<table>

			<tr><th>IMPORT TO</th></tr>
			<tr><th>Session<td><?php echo $db->getVal("select session from school_session where id='".$studetail['student_session']."'");?>
			</td></th></tr>
				<th> Class::  <td><?php  echo $db->getVal("select name from school_class where id='".$studetail['class']."'");  
				
				?></td></th>

							</table>

				<form method="POST">
				  <div class="col-md-9">
					<div class="zqw22 fttp">
					 <div class="panel with-nav-tabs panel-success">
					<div class="panel-heading">
					<div class="topside-section">
					<div class="card-box table-responsive">
					<div class="card-box">
				<table class="table table-striped table-bordered">
				<thead>
				<tr style="width: 20px;">
					<th>select Student</th>
					<th>Student id</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Other Name</th>
					<th>Gender</th>
					<th>DOB</th>
				</tr>
				</thead>
					<tbody>
					<?php $i=1; 
					
					$newtudentDetail=$db->getRows("select * from manage_student where class='".$newStudetail['id']."' and session='".$newStudetail['session_id']."' and create_by_userid='".$create_by_userid."'");
						foreach($newtudentDetail as $iList){ ?>
					<tr>
						<td><input type="checkbox" name="class_id[]" value="<?php echo$iList['id']; ?>" ></td>
						<td><?php echo $iList['student_id']; ?></td>
						<td><?php echo $iList['first_name']; ?></td>
						<td><?php echo $iList['last_name']; ?></td>
						<td><?php echo $iList['other_name']; ?></td>
						<td><?php echo $iList['gender']; ?></td>
						<td><?php echo $iList['date_of_birth']; ?></td>
					</tr>
					<?php } ?>
					</tbody>
						</thead>
			</table>
				 </div>
			<button style="float:right" type="submit" name="update_class_id" class="gwt-Button"/>Update Class
			</button>
		<a style="float:left" href="<?php echo $Filename; ?>" >BACK</a>
					</div>
					</div>
						</div>
							</div>
							</div>
							</div>
				</form>

			</div>

			</div>
			</div>
			</div>
		<?php } ?>

				</div>
					</div>
						</div>
					</div>
							</div>
							</div>
							</div>
							</div>

<?php include('inc.js.php'); ?>
<?php include('inc.footer.php'); ?>



<script>

$(document).ready(function () {
$('#example').DataTable();
});
</script>
</body>
</html>