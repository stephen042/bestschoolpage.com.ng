<?php
namespace Dompdf;
require_once ('./dompdf_New/autoload.inc.php');
echo "ok";
exit;
ob_start();
?>


<html>
 <head>
  <title>REPORT SHEET</title>
  <body style="border: 1px solid; background: url(logo.jfif);
    background-repeat: no-repeat;
    background-size: contain;    background-position: 50% 200px;">
   <table style="width:100%;">
<tr>
<td colspan="2" style="width: 90px;"> 
  <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <img style="width:40%" src="logo.jfif">
  </div>
</td>

<td colspan="3"> 
       <p style="font-size: 22px;color: #2196F3;font-weight: bolder;text-align: center;font-family: sans-serif;margin-bottom: 0;">FEDRAL AIRPORT AUTHORITY OF NIGERIA </p> 
       <p style="font-size: 22px;color: #2196F3;font-weight: bolder;text-align: center;font-family: sans-serif;margin-top:0px;margin-bottom:0px;">STAFF SECONDARY SCHOOL </p>     
       <p style="font-size: 12px;font-weight:600;text-align:center;font-family: sans-serif;margin-top:0px;">MOTTO: KNOWLEDGE AND DISCIPLINE</p>
	   <p style="font-size: 12px;font-weight:600;text-align:center;font-family: sans-serif;margin-top:0px;">AMINU KANO INTERNATIONAL AIRPORT, KANO</p>
	   <p style="font-size: 15px;text-align:center;font-family: sans-serif;margin-top:30px;margin-bottom:0px;">REPORT SHEET FOR FIRST TERM, 2018/2019 ACADEMIC SESSION</p>
</td>

</tr>

<table cellspacing="0"; style="width: 100%;">
<hr>
 <tbody style="font-family: sans-serif;">
<tr>
<td style="width:100%;" >


<table style="width:100%;">


<tr>
<td style="" colspan="3"><b>NAME:</b>EMMANUEL KINGSLEY CHISOM</td>
<td style="" colspan="3">Final Grade: B</td>
</tr>




<tr>
<td style=""><b>Class:</b></td>
<td style="">JSS 1 B</td>
<td style=""><b>Final Position:</b></td>
<td style="">5th</td>
<td style=""></td>
<td style=""></td>
</tr>


<tr>
<td></td>
</tr>
<tr>
<td></td>
</tr>



<tr>
<td style=""><b>Admission No:</b></td>
<td style="">18/4890</td>
<td style=""><b>Total Score:</b></td>

<td style="">1160.0</td>
<td style=""></td>
<td style=""></td>
</tr>



<tr>
<td style=""><b>Session:</b></td>
<td style="">2018/2019</td>
<td style=""><b>Final Average:</b></td>

<td style="">56.21</td>
<td style="">ATTENDANCE</td>
<td style=""></td>
</tr>
<tr>
<td style=""><b>Term:<b></td>
<td style="">FIRST</td>
<td style=""><b>Final Position:</b></td>

<td style="">56.00</td>
<td style=""><b>Days School Open:</b></td>
<td style="">55.00</td>
</tr>


<tr>
<td style=""><b>No. in Class:</b></td>
<td style="">54</td>
<td style=""><b>Highest Ave. in Class:</b></td>

<td style="">89.00</td>
<td style=""><b>Day(s) Present:</b></td>
<td style="">130.00</td>
</tr>
<tr>
<td style=""></td>
<td style=""></td>
<td style=""><b>Lowest Ave. in Class:</b></td>
<td style="">26.00</td>
<td style=""><b>Day(s) Absent:</b></td>
<td style="">55.00</td>
</tr>
</table>
</td>
</table>
</td>
</tr>
</tbody>
</table>

<table cellspacing="0"; style="width: 100%;">
 <tbody style="font-size: 18px;font-weight: bolder;font-family: sans-serif;">
	<tr style="height: 50px;">
    <td style="  border: 1px solid #000000;text-align: center;">SUBJECT</td>
    <td style="  border: 1px solid #000000;text-align: center;">CA <br>(40%)</td>
    <td style="  border: 1px solid #000000;text-align: center;">Exam<br>(60%)</td>
    <td style="  border: 1px solid #000000;text-align: center;">TOTAL<br>(100%)</td>
	<td style="  border: 1px solid #000000;text-align: center;">GRD</td>
    <td style="  border: 1px solid #000000;text-align: center;">POS</td>
    <td style="  border: 1px solid #000000;text-align: center;">OUT OF</td>
    <td style="  border: 1px solid #000000;text-align: center;">LOW.IN<br>CLASS</td>
	<td style="  border: 1px solid #000000;text-align: center;">HIGH.IN<br>CLASS</td>
	<td style="  border: 1px solid #000000;text-align: center;">CLASS<br>AVE</td>
	<td style="  border: 1px solid #000000;text-align: center;">COMMENT</td>
  
  </tr>
  
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>
<tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

    <tr style="height: 35px;">
    <td style="  font-weight: 100; border: 1px solid #000000;">English Language</td>
    <td style="  font-weight: 100; text-align: center;border: 1px solid #000000;">11.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">22.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">33.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">A</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">10</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">54</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">12.00</td>
	<td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">81.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">48.00</td>
    <td style="  font-weight: 100; text-align: center;  border: 1px solid #000000;">Good</td>
   
  </tr>

  
  </tbody>
</table>
</table>
  </body>
 </head>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();

$dompdf->setPaper('A4', 'landscape');
$dompdf->load_html($html);
$dompdf->render();
//For view
//$dompdf->stream("",array("Attachment" => false));
// for download
$dompdf->stream("cummulative_broad_sheet");
?>